using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace aueba.Models
{
    public class Personagem
    {
        [Key]
        [Required]
        public int PersonagemId { get; set; }

       
        [Required]
        [Column(TypeName = "varchar(20)")]
        [Display(Name = "Nome")]
        public string PersonagemNome { get; set; }

        [Required]
        [Display(Name = "Poder")]
        public int PersonagemPoder { get; set; }

        [Required]
        [Display(Name = "Vida")]
        public int PersonagemVida { get; set; }
    }
}