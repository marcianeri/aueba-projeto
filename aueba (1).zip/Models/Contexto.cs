using Microsoft.EntityFrameworkCore;

namespace aueba.Models
{
    public partial class Contexto : DbContext
    {
        public Contexto(){}

        public Contexto(DbContextOptions<Contexto> options): base(options)
        {
        }    

        public virtual DbSet<Personagem> Personagem { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Personagem>(entity =>
            {
                entity.Property(e => e.PersonagemId).HasColumnType("int(11)");

                entity.Property(e => e.PersonagemNome)
                    .IsRequired()
                    .HasColumnName("PersongemNome")
                    .HasColumnType("varchar(20)")
                    .HasCharSet("utf8")
                    .HasCollation("utf8_unicode_ci");

                entity.Property(e => e.PersonagemPoder)
                    .IsRequired()
                    .HasColumnName("PersonagemPoder")
                    .HasColumnType("int(11)");

                entity.Property(e => e.PersonagemVida)
                    .IsRequired()
                    .HasColumnName("PersonagemVida")
                    .HasColumnType("int(11)");
            });
            
            OnModelCreatingPartial(modelBuilder);
        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}